package com.SpringDemo;

public class ContactDetails {

	private String contactNumber;
	private String emailId;
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Override
	public String toString() {
		return "ContactDetails [contactNumber=" + contactNumber + ", emailId=" + emailId + "]";
	}
	
}
