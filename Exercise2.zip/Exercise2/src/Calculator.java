import java.util.Scanner;
public class Calculator {

	public void add(int a,int b) 
	{
		System.out.println(a+b);
		
	}
	public void add(double a,double b) 
	{
		System.out.println(a+b);
		
	}
	
	public void add(int a,double b) 
	{
		System.out.println(a+b);
		
	}
	
	public void add(double a,int b) 
	{
		System.out.println(a+b);
		
	}
	

	
	public void sub(int a,int b) 
	{
		System.out.println(a-b);
		
	}
	public void sub(double a,double b) 
	{
		System.out.println(a-b);
		
	}
	
	public void sub(int a,double b) 
	{
		System.out.println(a-b);
		
	}
	
	public void sub(double a,int b) 
	{
		System.out.println(a-b);
		
	}
	


	
	public void mul(int a,int b) 
	{
		System.out.println(a*b);
		
	}
	public void mul(double a,double b) 
	{
		System.out.println(a*b);
		
	}
	
	public void mul(int a,double b) 
	{
		System.out.println(a*b);
		
	}
	
	public void mul(double a,int b) 
	{
		System.out.println(a*b);
		
	}
	

	
	public void div(int a,int b) 
	{
		System.out.println(a/b);
		
	}
	public void div(double a,double b) 
	{
		System.out.println(a/b);
		
	}
	
	public void div(int a,double b) 
	{
		System.out.println(a/b);
		
	}
	
	public void div(double a,int b) 
	{
		System.out.println(a/b);

		
	}
	
	public static void main(String[] args) {
	 Calculator c1=new Calculator();
	 c1.add(3,4);
	 c1.sub(54.1, 9.0);
	 c1.mul(5,7);
	 c1.mul(23,78);
	 
		
	}
}
