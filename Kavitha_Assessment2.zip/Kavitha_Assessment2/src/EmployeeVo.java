
public class EmployeeVo {
	
	private int empId;
	private String empName;
	private double annualIncome;
	private double incomeTax;
	
	public EmployeeVo() {
		// TODO Auto-generated constructor stub
	}
	
	
	public EmployeeVo(int empId, String empName, double d, double e) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.annualIncome = d;
		this.incomeTax = e;
	}


	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getAnnualIncome() {
		return annualIncome;
	}
	public void setAnnualIncome(double newAnnualIncome) {
		this.annualIncome = (int) newAnnualIncome;
	}
	public double getIncomeTax() {
		return incomeTax;
	}
	public void setIncomeTax(double incomeTax) {
		this.incomeTax = incomeTax;
	}


	@Override
	public String toString() {
		return "EmployeeVo [empId=" + empId + ", empName=" + empName + ", annualIncome=" + annualIncome + ", incomeTax="
				+ incomeTax + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		double result = 1;
		result = prime * result + annualIncome;
		result = prime * result + empId;
		result = prime * result + ((empName == null) ? 0 : empName.hashCode());
		result = prime * result + incomeTax;
		return (int) result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeVo other = (EmployeeVo) obj;
		if (annualIncome != other.annualIncome)
			return false;
		if (empId != other.empId)
			return false;
		if (empName == null) {
			if (other.empName != null)
				return false;
		} else if (!empName.equals(other.empName))
			return false;
		if (incomeTax != other.incomeTax)
			return false;
		return true;
	}


	public void setAnnualIncome1(double newAnnualIncome) {
		// TODO Auto-generated method stub
		
	}
	
	

}
