import java.util.Scanner;
			
public class Calculator{
	
      public  void main(String[] args) 
      {
	
      Object[] operator = {new Addition(), new Subtraction(), new Multiplication(), new Div() };
		System.out.println("Enter your choice:1. Add  2. Sub . Multiply 4. Divide");
		int input1;
		Scanner sc = new Scanner(System.in);
		input1 = sc.nextInt();
		int input2;
		Scanner sc1 = new Scanner(System.in);
		input2 = sc1.nextInt();
		
		int num1, num2;
		System.out.println("Enter two numbers: ");
		num1 = sc.nextInt();
		num2 = sc.nextInt();
		int y = ((Arithmetic)operator[input1-1]).calculator(num1, num2);
		System.out.println(y);
		sc.close();

}
      

      public abstract class Arithmetic {
  		
  		abstract int calculator(int x,int y);
  			
  		}
  	

  		public class Addition extends Arithmetic {
  			
  		
  			public int calculator (int num1, int num2) {
  				return num1+num2;
  			}
  		}
  	
  				public class Subtraction extends Arithmetic {
  					public int calculator (int num1, int num2) {
  						return num1-num2;
  					}
  				}
  					
  					
  		public class Multiplication extends Arithmetic {
  		public int calculator (int num1, int num2) {
  								return num1*num2;
  							}
  		}	
  			
  								

  			public class Div extends Arithmetic {
  						public int calculator (int num1, int num2)
  						{
  							return num1/num2;
  									}
  			}
  									 
      
}
  		