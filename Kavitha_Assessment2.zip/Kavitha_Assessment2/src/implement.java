import java.util.Comparator;

public interface implement extends Comparator<EmployeeVo> {

	@Override
	default int compare(EmployeeVo e1, EmployeeVo e2) {
		// TODO Auto-generated method stub
		
		if(e1.getIncomeTax()>e2.getIncomeTax())
		return 0;
		else
			return -1;
		
		
	}

	
	

}
