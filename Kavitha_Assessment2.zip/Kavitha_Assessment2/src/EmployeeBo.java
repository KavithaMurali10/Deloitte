
public class EmployeeBo {
	
	public void calincomeTax(EmployeeVo e1 )
	{
		double annualIncome=e1.getAnnualIncome();
		
		double newAnnualIncome=(0.20*annualIncome)+annualIncome;
		e1.setAnnualIncome(newAnnualIncome);
		
		
	}

}
