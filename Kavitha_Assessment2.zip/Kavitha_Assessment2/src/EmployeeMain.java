import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class EmployeeMain {

	public static void main(String[] args) {
		
		
		
		
		List<EmployeeVo> allEmployees=new ArrayList<EmployeeVo>();
		
		EmployeeVo e1=new EmployeeVo(101,"Karan",50000.0,10000.0);
		EmployeeVo e2=new EmployeeVo(102,"Tarun",60000.0,10000.0);
		EmployeeVo e3=new EmployeeVo(101,"Varun",80000.0,10000.0);
		
		allEmployees.add(e1);
		allEmployees.add(e2);
		allEmployees.add(e3);
		
		System.out.println(allEmployees);
		
		 

			 Collections.sort(allEmployees, new implement());

			 Iterator <EmployeeVo> i= allEmployees.iterator();

				while (i.hasNext()) {

					EmployeeVo employee = i.next();

					System.out.println(employee);
				}

				
	}
}
