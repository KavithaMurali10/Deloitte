
public abstract class Arithmetic {
	
	abstract int calculator(int num1,int num2);
		
	}



	


