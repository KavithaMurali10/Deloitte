
public class Outer {
	
	String password="pass123#";
	
	class Inner
	{
		int passwordLevel=5;
		public void doEncrypt()
		{
			System.out.println("The password is:"+password);
		}
	}

	
}