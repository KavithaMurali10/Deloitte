

public class Demo02 {
	public static void main(String[] args) {
		Outer password=new Outer();
		Outer.Inner e=password.new Inner();
		e.doEncrypt();
	}
}
