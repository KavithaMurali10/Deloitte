import java.util.StringTokenizer;
public class Stringtok {
public static void main(String[] args) {
	String text="The quick brown fox jumps over the lazy dog";
	StringTokenizer tokenizer=new StringTokenizer(text);
	System.out.println(tokenizer.hasMoreTokens());
	while(tokenizer.hasMoreTokens())
	{
		System.out.println(tokenizer.nextElement());
		
	}
}
}
