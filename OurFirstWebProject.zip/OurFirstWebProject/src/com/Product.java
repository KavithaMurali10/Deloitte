package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;


public class Product extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Product() {
        super();
        // TODO Auto-generated constructor stub
    }

   
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	/*int customerId=Integer.parseInt(request.getParameter("customerId"));*/
	String username=request.getParameter("username");
	String password=request.getParameter("password");
	
	Customer customer=new Customer(customerId,customerName,customerAddress,billAmount);
	CustomerDAO customerDAO=new CustomerDAOImpl();
	
	if(customerDAO.isCustomerExists(customerId))
	{
		response.getWriter().println(customerId+ "already exists");
	}
	
	else
		
	{
		customerDAO.addCustomer(customer);
		response.getWriter().println(customerName+ "saved successfully");
	}
	response.getWriter().println("<h1>Welcome to Shop </h1>");
	response.getWriter().println("<h1>Product list </h1>");
	String usern=request.getParameter("username");
	String pass=request.getParameter("password");
	
	response.getWriter().println("<h1>Welcome to my website-"+usern+"</h1>");
	response.getWriter().println("<h1>Your password: -"+pass+"</h1>");
	
	
	response.getWriter().println("<h1><a href='custform.html'>Shop</a>");

}
}