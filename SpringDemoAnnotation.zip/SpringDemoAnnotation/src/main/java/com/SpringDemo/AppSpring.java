package com.SpringDemo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.config.AppConfig;

public class AppSpring {
	
	public static void main(String args[])
	{	
		
		//Resource resource=new ClassPathResource("beans.xml");
		//BeanFactory factory=new XmlBeanFactory(resource);
		AbstractApplicationContext context=new AnnotationConfigApplicationContext(AppConfig.class);
		Customer customer=context.getBean(Customer.class);
		System.out.println("Cons called");
		customer.setCustomerId(1990);
		customer.setCustomerName("Jaya");
		customer.setCustomerAddress("Mumbai");
		customer.setBillAmount(7800);
		
		ContactDetails contactDetails=context.getBean(ContactDetails.class);
		contactDetails.setContactNumber("98765345");
		contactDetails.setEmailId("jaya@gmail.com");
		customer.setContactDetails(contactDetails);
		
		System.out.println(customer);
		System.out.println(customer);
		
		context.registerShutdownHook();
	}

}
