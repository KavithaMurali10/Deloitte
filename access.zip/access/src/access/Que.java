package access;

public class Que {
	W w=new W();
	 
	 {
		 System.out.println("Instance block");
		 
	 }
	 static
	 {
		System.out.println("Static block"); 
	 }
	 public void  Z()
	 {
		 System.out.println("Z constructor");
		 
	 }
	 
	 public static void main(String[] args) {
		System.out.println("in main");
		Que q1=new Que();
		q1.Z();
		
	}

}
