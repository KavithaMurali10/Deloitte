package access;

public class W {
	
	public W()
	{
	System.out.println("W constructor");
	}
}
