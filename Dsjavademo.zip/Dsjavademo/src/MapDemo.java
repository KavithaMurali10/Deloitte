import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class MapDemo {
	
	public static void main(String[] args) {
		HashMap<String,Double> hm=new HashMap<String,Double>();
		
		hm.put("John",new Double(3434.34));
		hm.put("Smith",new Double(123.45));
		hm.put("Mill",new Double(456.81));
		hm.put("Jane",new Double(56007.87));
		hm.put("Jane",new Double(-19.678));
		Set set=hm.entrySet();
		Iterator i=set.iterator();
		
		while(i.hasNext())
		{
			Map.Entry me=(Map.Entry)i.next();
			System.out.print(me.getKey()+":");
			System.out.println(me.getValue());
		}
		
		System.out.println();
		
		double balance=((Double)hm.get("John")).doubleValue();
		hm.put("John", new Double(balance + 1000));
		Iterator r=set.iterator();

		while(r.hasNext())
		{
			Map.Entry me=(Map.Entry)r.next();
			System.out.print(me.getKey()+":");
			System.out.println(me.getValue());
		}
		
		System.out.println();
	}

}
