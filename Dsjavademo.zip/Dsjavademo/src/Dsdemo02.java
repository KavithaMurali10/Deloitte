import java.awt.List;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
public class Dsdemo02 {



	public static void main(String[] args)
	
	
	{ 
		Set<String> names=new LinkedHashSet<String>();
	  names.add("shradha");
	  names.add("sh");
	  names.add("radha");
	 
	  	  
	  	    System.out.println(names);
	  	    
	  	    Iterator<String> i=names.iterator();
	  	    
	  	    while(i.hasNext())
	  	    {
	  	    	String str=i.next();
	  	    	if(str.equals("sh"))
	  	    		continue;
	  	    	 System.out.println(str);
	  	    	
	  	    }
	  
	  
		
	}
}

