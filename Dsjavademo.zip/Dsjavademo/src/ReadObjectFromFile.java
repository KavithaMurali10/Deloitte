import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ReadObjectFromFile {
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		CustomerDet customer=new CustomerDet();
		
		ObjectInputStream stream=new ObjectInputStream(new BufferedInputStream(
				new FileInputStream(new File("C:\\deloitte\\iodemo.txt"))));
		
		customer=(CustomerDet)stream.readObject();
		
		System.out.println(customer);
	}

}
