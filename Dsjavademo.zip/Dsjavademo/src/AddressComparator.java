import java.util.Comparator;

public class AddressComparator implements Comparator<CustomerDet> {

	@Override
	public int compare(CustomerDet c1, CustomerDet c2) {
		
		
		
		if((c1.getCustomerAddress().compareTo(c2.getCustomerAddress())>0))
				{
			return 0;
				}
		else
		{
			return -1;
		}
		
	
		
		
	}
}
		// TODO Auto-generated method stub
		
		
