import java.io.File;
import java.io.IOException;
public class Filedemo {

	public static void main(String[] args) throws IOException {
		
		File file=new File("C:\\deloitte\\Batch\\BatchMates.txt");
		File h=new File("c:\\deloitte\\Batch");
		
			 
		h.mkdirs();
		file.createNewFile();
		System.out.println("File created");
	
	System.out.println("Done");
	
	File[] file1= h.listFiles();

	for(File file2 : file1 ) {

		if(file2.isFile()) {

			System.out.println(file2 +" is a file");

		

	}

		else if(file2.isDirectory()) {

			System.out.println(file2 +" is a folder");

		

	}
     }
}
	
}