import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
public class MainCustdet {

	public static void main(String[] args) throws FileNotFoundException,IOException  {
		
		CustomerDet customer =new CustomerDet();
		customer.accept();
		
		ObjectOutputStream stream=new ObjectOutputStream(new BufferedOutputStream(
				new FileOutputStream(new File("C:\\deloitte\\iodemo.txt"))));
		
		stream.writeObject(customer);
		
		stream.close();
		System.out.println("Data Stored");
	}
}
