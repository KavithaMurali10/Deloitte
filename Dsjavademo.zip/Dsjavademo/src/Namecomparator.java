import java.util.Comparator;

public class Namecomparator implements Comparator<CustomerDet> {

	@Override
	public int compare(CustomerDet c1, CustomerDet c2) {
		
		if((c1.getCustomerName().compareTo(c2.getCustomerName())>0))
		// TODO Auto-generated method stub
		{
		return 0;
		}
		else
		{
			return -1;
		}
	}

	
	
	

}
