

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;



public class Customermain {

	public static void main(String[] args) {
		
		List<CustomerDet> allCustomers =new ArrayList<CustomerDet>();
		
		CustomerDet customer1=new CustomerDet(101,"Kavitha","Kerala",50000);
		
		 allCustomers.add(customer1);
		 allCustomers.add(new CustomerDet(102,"Pooja","Bangalore",68000));
		 allCustomers.add(new CustomerDet(103,"Pavithra","Delhi",4000));
		 allCustomers.add(new CustomerDet(104,"Tarun","Mumbai",55000));
		 
		  
	  	   
		 System.out.println(allCustomers);
		 System.out.println("Sort on 1)Name 2)Address 3)BillAmount ");
		  Scanner sc=new Scanner(System.in);
		  int choice=sc.nextInt();
		  
	  	    
		 
		 if(choice==3)
		 {
	  	    
		 Collections.sort(allCustomers);
		 System.out.println("After sorting Billamount");
		 System.out.println(allCustomers);
		 }
		 if(choice==2)
		 {
	  	    
		 Collections.sort(allCustomers,new Comparator<CustomerDet>()
				 {
			 
			 public int compare(CustomerDet o1,CustomerDet o2)
			 {
				 if((o1.getCustomerAddress().compareTo(o2.getCustomerAddress())>0))
						 {
					 return 0;
						 }
				 else
				 {
					 return -1;
				 }
			 }
				 });
		 System.out.println("After sorting Address");
		 System.out.println(allCustomers);
		 }	
		 
		 
		 if(choice==1)
		 {
	  	    
		 Collections.sort(allCustomers , new Namecomparator());
		 System.out.println("After sorting name");
		 System.out.println(allCustomers);
		 }
		 
}
}
