package collectiondemo;
import java.util.ArrayList;
import java.util.List;

public class Listdemo {
	
	public static void main(String[] args)
	{
		List names=new ArrayList();
		names.add("Shradha");
		names.add("Kavi");
		names.add("Vandu");
		names.add("Vandu");
		
		System.out.println(names);
		names.add(2,"Reddy");
		System.out.println(names);
		names.remove("Vandu");
		System.out.println(names.isEmpty());
		
		
		
		
		
	}

}
