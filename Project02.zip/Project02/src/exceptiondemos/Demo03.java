package exceptiondemos;

public class Demo03 {
	
	
	public void dispaly() throws InterruptedException
	{
		System.out.println("Welcome in display");
		Thread.sleep(1000);
		System.out.println("Bye");
	}
	public void dispaly2() throws InterruptedException
	{
		System.out.println("Welcome in display");
		Thread.sleep(1000);
		System.out.println("Bye");
	}

	public static void main(String[] args) throws InterruptedException {
		System.out.println("MAIN STARTED");
		Demo03 d=new Demo03();
		d.dispaly();
		d.dispaly();
		System.out.println("MAIN ENDED");

	}
}
