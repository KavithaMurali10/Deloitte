package exceptiondemos;
import java.util.Scanner;


class InvalidAgeException extends Exception
{ public InvalidAgeException()
	{

	}
public InvalidAgeException(String msg)
	{
	System.out.println(msg);
	}

}

class NewYearParty
{
	int eligibleage=16;
	Scanner sc=new Scanner(System.in);
	int age;
	
	public void enterClub() throws InvalidAgeException
	{
		System.out.println("Enter your age:");
		Scanner sc=new Scanner(System.in);
		age=sc.nextInt();
		if(age<eligibleage)
		{
			throw new  InvalidAgeException("Under age");
		}
		else
		{
			System.out.println("You are welcome.");
		}
	}
	
	public class Demo05 {
		
		public static void main(String[] args) 
		{
			
			NewYearParty p1=new NewYearParty();
			try {
			p1.enterClub();
		}
 catch(InvalidAgeException e)
			{
	 e.printStackTrace();
	 }
			System.out.println("enjoy");
			}
	}
	
	
}

