package exceptiondemos;

public class Customer {
	
	private int CustomerId;
	private String CustomerName;
	private String CustomerAddress;
	private int Amount;
	
	public Customer() {
		super();
	}
	public Customer(int customerId, String customerName, String customerAddress, int amount) {
		super();
		CustomerId = customerId;
		CustomerName = customerName;
		CustomerAddress = customerAddress;
		Amount = amount;
	}
	public Customer(int customerId2, String customerName2, String customerAddress2, int amount2) {
		// TODO Auto-generated constructor stub
	}
	public int getCustomerId() {
		return CustomerId;
	}
	public void setCustomerId(int customerId) {
		CustomerId = customerId;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getCustomerAddress() {
		return CustomerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		CustomerAddress = customerAddress;
	}
	public int getAmount() {
		return Amount;
	}
	public void setAmount(int amount) {
		Amount = amount;
	}
	@Override
	public String toString() {
		return "Customer [CustomerId=" + CustomerId + ", CustomerName=" + CustomerName + ", CustomerAddress="
				+ CustomerAddress + ", Amount=" + Amount + "]";
	}
	
}
