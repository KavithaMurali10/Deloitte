package exceptiondemos;
import java.util.InputMismatchException;
import java.util.Scanner;


public class Demoexc01 {
	int num1=0,num2=0;
	int result;
	Scanner sc=new Scanner(System.in);
	
	public void display()
	{
		System.out.println("wecome to display");
		try {
		System.out.println("Enter first number");
		num1=sc.nextInt();
		System.out.println("Enter second number");
		num2=sc.nextInt();
		result=num1/num2;
		System.out.println(result);
		
	}
		
		catch(InputMismatchException e)
		{
			System.out.println("enter numbers only");
			}
		
		catch(ArithmeticException e)
		{
			System.out.println("Division with 0 is not possible");
		}
		
	}
	
	
	
	public static void main(String[] args)
	{
		
		Demoexc01 d1=new Demoexc01();
		d1.display();
		System.out.println("bye");
	}

}
