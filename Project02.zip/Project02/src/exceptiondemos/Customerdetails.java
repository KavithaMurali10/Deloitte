package exceptiondemos;

public class Customerdetails {
  public static void main(String[] args)
  {
	  Customer c1=new Customer(1001,"Kavitha","Kerala",5000);
	  System.out.println(c1);
	  
  }

}
