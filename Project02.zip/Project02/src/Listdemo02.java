import java.awt.List;
import java.util.LinkedHashSet;
public class Listdemo02 {

	public static void main(String[] args)
	
	
	{ LinkedHashSet names=new LinkedHashSet();
	  names.add("shradha");
	  names.add("sh");
	  names.add("radha");
	  System.out.println(names);
	  
	  
		
	}
}
