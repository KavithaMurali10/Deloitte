package com.shopping.deloitte.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AuthenticateServlet
 */
public class AuthenticateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AuthenticateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username= request.getParameter("username");
		String password= request.getParameter("password");
		PrintWriter out= response.getWriter();
		out.println("<h2>Welcome "+username);
		out.println("<h2>You are being authenticated</h2>");
		Cookie allCookies[] = request.getCookies();
		boolean alreadyVisited= false;
		if(allCookies!=null) {
			for(Cookie c : allCookies) {
				if(c.getName().equals(username)) {
					alreadyVisited=true;
					break;
				}
			}
		}
		out.println("<h1>Successfully authenticated");
		if(! alreadyVisited) {
			out.println("<h2>Welcome you are a first time visitor, "+username);
			Cookie cookie = new Cookie(username,username);
			response.addCookie(cookie);
		}
		else {
			out.println("<h1> Welcome, you have already visited my website");
		}
		
		
	//	if(username.startsWith("T")) {
			//out.println("h2><a href=Item.html>Item</a>");
			RequestDispatcher  dispatcher= request.getRequestDispatcher("WelcomeServlet");
			dispatcher.include(request, response);
	//	}
		//else {
			//out.println("invalid username");
			//out.println("<h2><a href=index.html>Home</a>");
		//	response.sendRedirect("loginform3.html");
		//}
		
	}

}
