package com.shopping.deloitte.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class CustomerProductServlet
 */
public class CustomerProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String selectedItems[]= request.getParameterValues("item");
		HttpSession session = request.getSession();
		String str = (String) session.getAttribute("currentBuyer");
		
		
		PrintWriter out= response.getWriter();
		if(selectedItems==null) {
			response.getWriter().println("Select atleast 1 product "+ str );
			response.getWriter().println("<a href= Item.html>    Go Back</a>");
		}
		else {
			out.println("<h1>" + str +"</h>");
			out.println("<h1>" +" You have selected the following products : ");
			for(String product :selectedItems) {
				out.println("<h2>"+ product+"</h2>");
			}
		}
	}

}
