package com;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client {

	public static void main(String args[]) {

		Configuration cfg = new Configuration().configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

			
		Transaction tx = session.beginTransaction();

		Employee employee=new Employee(679,"Karina");
		
		
	/*	RegularEmployee employee=new RegularEmployee(41000,70000);
		employee.setEmployeeId(569);
		employee.setEmployeeName("Ninu");*/
		
		
		/*ContractEmployee employee=new ContractEmployee(20,20000);
		employee.setEmployeeId(278);
		employee.setEmployeeName("Arun");*/
		
       session.save(employee);
		tx.commit();
		session.close();
		System.out.println(" details saved!!");
		factory.close();

	}
}
