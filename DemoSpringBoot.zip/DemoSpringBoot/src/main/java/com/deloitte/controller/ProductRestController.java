
package com.deloitte.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import com.deloitte.dao.ProductDAO;
import com.deloitte.model.Product;
import com.deloitte.service.ProductService;

@RestController
@RequestMapping("product")
public class ProductRestController {
	
	
	@Autowired
	ProductService productService;
	@RequestMapping("getProduct")
	public List<Product> Product()
	{
		
		List<Product>allListProduct=productService.listProduct();
		
		
		return allListProduct;
	}
/*
	
	@RequestMapping("/saveProduct")
	public ModelAndView saveProduct(Product product )
	{
		ModelAndView view=new ModelAndView("redirect:/Product");
		view.addObject("product",new Product());
		
		System.out.println(product);
		productService.addProduct(product);
			return view;
	}
	
	
	
	@RequestMapping("/deleteProduct/{prodId}")
	public ModelAndView deleteProduct(@PathVariable("prodId")Integer productId )
	{	
		
		System.out.println("Delete product called" +productId);
		productService.deleteProduct(productId);
		ModelAndView view=new ModelAndView("redirect:/Product");
		view.addObject("product",new Product());
					return view;
	}
	
	@RequestMapping("/editProduct/{prodId}")
	public ModelAndView editProduct(@PathVariable("prodId")Integer productId )
	{	
		
		System.out.println("Fetch product called" +productId);
		Product product=productService.getProduct(productId);
		ModelAndView view=new ModelAndView("product");
		List<Product>allListProduct=productService.listProduct();
				view.addObject("allProduct",allListProduct);
		view.addObject("product",product);
		
		productService.updateProduct(product);
					return view;
					
					
			
	}
	
	@RequestMapping(value="/editProduct/add/update")
	
	public String updatePerson(Product product)
	{
		System.out.println("updating"+ product);
		this.productService.updateProduct(product);
		return "redirect:/Product";
	}
		
		
	
	
	
	
	*/
	
	
	
	
	

}
