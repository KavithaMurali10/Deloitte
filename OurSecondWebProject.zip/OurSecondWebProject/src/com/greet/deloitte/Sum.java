package com.greet.deloitte;

public class Sum {
	public int addNumbers(int i,int j)
	{
		return i+j;
	}

}
