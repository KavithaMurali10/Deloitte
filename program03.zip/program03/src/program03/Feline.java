package program03;

abstract class Feline extends Animal {
	
	public void roam()
	{
		System.out.println("Felines roam");
	}

}
 class Lion extends Feline
{
	 public void makeNoise()
	 {	
	 
		 System.out.println("Lion roars");
	 }
	 
	 public void eat()
	 {
		 System.out.println("Lion eats meat");
	 }
	
}
 class Tiger extends Feline
 {
 	 public void makeNoise()
 	 {	
 	 
 		 System.out.println("Tiger roars");
 	 }
 	 
 	 public void eat()
 	 {
 		 System.out.println("Tiger eats meat");
 	 }
 	
 }
 
 class Cat extends Feline
 {
 	 public void makeNoise()
 	 {	
 	 
 		 System.out.println("Cat meow");
 	 }
 	 
 	 public void eat()
 	 {
 		 System.out.println("Cat drinks milk");
 	 }
 	
 }
 