package program03;

public abstract class Demo1 {
	public static void main(String[] args) {
		Animal a=new Lion();
		a.makeNoise();
		a.eat();
		a.sleep();
		a.roam();
		a=new Tiger();
		a.makeNoise();
		a.eat();
		a.sleep();
		a.roam();
		a=new Cat();
		a.makeNoise();
		a.eat();
		a.sleep();
		a.roam();
		
		
	}
}