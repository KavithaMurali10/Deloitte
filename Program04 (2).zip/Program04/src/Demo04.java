
interface ChangePassword
{
	void doChange();
}
public class Demo04 {
 public static void main(String[] args)
 {
	 ChangePassword p1=new ChangePassword()
			 {
		 public void doChange()
		 {
			 System.out.println("Password changed");
		 }
			 };
			 p1.doChange();
 }

}
