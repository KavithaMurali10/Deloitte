
public class Product {
	
	public static void main(String[] args)
	{
		Productdetails p1=new Productdetails(101,"TV",5,20000);
		System.out.println(p1);
		Productdetails p2=new Productdetails(101,"TV",5,20000);
		System.out.println(p1);
		System.out.println(p1.equals(p2));
	}

}
