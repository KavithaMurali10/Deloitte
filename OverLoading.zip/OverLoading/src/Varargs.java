
public class Varargs {

}
