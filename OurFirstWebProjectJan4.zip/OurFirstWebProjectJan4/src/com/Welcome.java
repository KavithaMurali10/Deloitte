package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Welcome
 */
public class Welcome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Welcome() {
       System.out.println("Welcome cons");
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
    int counter=0;
    
		
	
	@Override
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		counter++;
//		String un=request.getParameter("username");
//		String pass=request.getParameter("password");
		
//		response.getWriter().println("<h1>Welcome to my website " + un+"</h>");
//		response.getWriter().println("<h1>Your password is  " + pass+"</h>");
//		response.getWriter().println("<h1>You are visitor number : "+ counter);
//		response.getWriter().println("<a href='Shop.html'>Shop</a>");
//		System.out.println("doget called");
		
//	}
//	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		counter++;
		String un=request.getParameter("username");
		String pass=request.getParameter("password");
		
		response.getWriter().println("<h1>Welcome to my website " + un+"</h>");
		response.getWriter().println("<h1>Your password is  " + pass+"</h>");
		response.getWriter().println("<h1>You are visitor number : "+ counter);
		response.getWriter().println("<a href='Shop.html'>Shop</a>");
		System.out.println("dopost called");
		
	}
//	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		counter++;
//		String un=request.getParameter("username");
//		String pass=request.getParameter("password");
//		
//		response.getWriter().println("<h1>Welcome to my website " + un+"</h>");
//		response.getWriter().println("<h1>Your password is  " + pass+"</h>");
//		response.getWriter().println("<h1>You are visitor number : "+ counter);
//		response.getWriter().println("<a href='Shop.html'>Shop</a>");
//		System.out.println("service called");
		
//	}
	public void init() {
		System.out.println("init called");
	}
	public void destroy() {
		System.out.println("destroyed");
	}
	
	

}
