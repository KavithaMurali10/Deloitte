import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.io.BufferedReader;
import java.io.BufferedWriter;
public class Shortcut_demo {

	public static void main(String[] args) throws IOException {
		
		BufferedReader bufferedReader=
				new BufferedReader(new FileReader(new File("C:\\deloitte\\iodemo.txt")));
		
		BufferedWriter bufferedWriter=
				new BufferedWriter(new FileWriter(new File("C:\\deloitte\\iodemo2.txt")));
		int i=0;
		while((i=bufferedReader.read())!=-1)
		{
			bufferedWriter.write((char)i);
		}
		bufferedReader.close();
		bufferedWriter.close();
	}
}
