import java.io.File;
public class Seperatordemo {
public static void main(String[] args) {
	String fs=File.separator;
	File file=new File("C:\\Deloitte\\Batch\\batchmate.txt");
}
}
