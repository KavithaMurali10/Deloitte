
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class Readwriteex2 {

	public static void main(String[] args) throws IOException {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter file to read");
	String ufile=sc.next();
	File file1=new File (ufile);
	if(file1.exists())
	{
		System.out.println("Enter the file to paste:");
		String uwfile=sc.next();
		
		File file2=new File(uwfile);
		FileReader fr=new FileReader(file1);
		FileWriter fw=new FileWriter(file2);
	
		int i=0;
		while((i=uwfile.read())!=-1)
			
		{
			fw.write((char)i);
		}
		
		fr.close();
		fw.close();
		System.out.print("\""+
	}
	
	
}
