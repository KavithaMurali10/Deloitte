
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class Readwriteexercise {

	public static void main(String[] args) throws IOException {
		File file=new File("C:\\deloitte\\iodemo.txt");
		FileReader reader=new FileReader(file);
		FileWriter fw=new FileWriter("C:\\deloitte\\iodemo2.txt");
		int i=0;
		while((i=reader.read())!=-1)
			
		{
			fw.write((char)i);
		}
		
		reader.close();
		fw.close();
	}
	
	
}
