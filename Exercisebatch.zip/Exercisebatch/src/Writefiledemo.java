import java.io.File;
import java.io.FileNotFoundException;

import java.io.FileWriter;
import java.io.IOException;

public class Writefiledemo {
	public static void main(String[] args) throws IOException {
		
		FileWriter fw=new FileWriter("C:\\deloitte\\iodemo.txt");
		fw.write("My name is Kavitha");
		
		fw.close();
		System.out.println("Done");
	}
	

}
