package com.product.dao;

import java.util.List;


import com.product.Product;

public interface ProductDAO {

	
	public void updateProduct(Product product);
	public List<Product> diplayproduct();
	
	
}
