package com.product.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;


import com.product.Product;
import com.product.dao.ProductDAO;

public class ProductImpl implements ProductDAO{


	Configuration configuration=null;
	SessionFactory factory= null;
		
		public ProductImpl() {
			
			configuration= new Configuration().configure();
			factory= configuration.buildSessionFactory();
			
		}
		

		@Override
		public void updateProduct(Product product) { {
			
			
			
			Session session= factory.openSession();
			
			Transaction transaction= session.beginTransaction();
			session.save(product);
			transaction.commit();
			session.close();
			
		}

	}

	@Override
	public List<Product> diplayproduct() {
		
			Session session= factory.openSession();
			Query query= session.createQuery("from Product");
			return query.list();
			
	}
		
		
	

}

