package com.product;

import java.io.Serializable;
import java.util.Scanner;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="hr.Product500")
public class Product implements Serializable{
	@Id
	private String productId;
	
	@Column(name="Pname")
	private String PName;
	@Column
	private String qoa;
	@Column
	private String price;
	
	public Product() {
	}
	
	
	


	public Product(String productId2, String pName, String qoh, String price2) {
		super();
		this.productId = productId2;
		this.PName = pName;
		this.qoa = qoa;
		this.price = price;
	}


	
	public String getProductId() {
		return productId;
	}


	public void setProductId(String productId) {
		this.productId = productId;
	}


	public String getPName() {
		return PName;
	}


	public void setPName(String pName) {
		PName = pName;
	}


	public String getQoa() {
		return qoa;
	}


	public void setQoa(String qoa) {
		this.qoa = qoa;
	}


	public String getPrice() {
		return price;
	}


	public void setPrice(String price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "Product [productId=" + productId + ", PName=" + PName + ", qoa=" + qoa + ", price=" + price + "]";
	}


	
	

}
