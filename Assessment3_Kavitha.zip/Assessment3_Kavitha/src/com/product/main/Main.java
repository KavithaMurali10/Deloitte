package com.product.main;


import com.product.dao.ProductDAO;
import com.product.dao.impl.ProductImpl;

public class Main {
	public static void main(String args[])
	{
		ProductDAO productDAO=new ProductImpl();
		
		
	}

}
