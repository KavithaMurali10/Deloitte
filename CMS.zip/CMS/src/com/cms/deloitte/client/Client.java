package com.cms.deloitte.client;

public class Client {

	public static void main(String[] args) {
		LaunchCustomerApplication.startCustomerApp();
		

	}

}
