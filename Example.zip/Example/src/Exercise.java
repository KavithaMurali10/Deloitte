
public class Exercise {
	public static void main(String[] args) {
		String str="The quick brown fox jumps over the lazy dog";
		System.out.println(str.charAt(12));
		
		if(str.contains("is"))
		{
		  System.out.println("yes");
		}
		else
		{
			System.out.println("no");
		}
		String str1=" and killed it";
		
		
		System.out.println(str.concat(str1));
		
		String str2="The quick brown Fox jumps over the lazy Dog";
		
		if(str.equals(str2))
		{
			System.out.println("yes");
		}
		else
		{
			System.out.println("no");

		}
		
		String str3="THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG";
		if(str.equals(str3))
		{
			System.out.println("yes");
		}
		else
		{
			System.out.println("no");

		}
		
		System.out.println(str.length());
		
		System.out.println(str.toLowerCase());
		System.out.println(str.toUpperCase());
		

		
	}

}
