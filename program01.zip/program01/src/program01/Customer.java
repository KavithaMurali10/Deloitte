package program01;

public class Customer {

	private int id;
	private String customerName;
	private String customerAddress;
	private int billAmount;
	
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(int billAmount) {
		this.billAmount = billAmount;
	}
	public int getId() {
		return id;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	
	public Customer() {
		id=0;
		customerName="null";
		customerAddress="null";
		billAmount=0;
		System.out.println("Customer called");
	}
	public Customer(int id, String customerName, String customerAddress, int billAmount) {
		super();
		this.id = id;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
		this.billAmount = billAmount;
	}
	public void printDetails()
	{
		System.out.println("Id "+ id);
		System.out.println("Name: "+ customerName);
		System.out.println("Adddress:" +customerAddress);
		System.out.println("BillAmount:" + billAmount);
		
	}
	public static void main(String[] args) {
		Customer c1=new Customer(12,"Mohan","mumbai",5000);
		Customer c2=new Customer();
		c1.printDetails();
		
	}
	
	
}
