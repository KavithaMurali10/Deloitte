package program01;

public class thirdday {

}
