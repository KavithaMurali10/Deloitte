package program01;

public class Client {
	public static void main(String[] args) {
		Customer c3=new Customer();
		c3.getCustomerName();
		c3.setCustomerName("Mohan");
		c3.getCustomerAddress();
		c3.setBillAmount(5000);
		c3.getBillAmount();
		
	
		
		c3.printDetails();
	
		
		
		
	}

}
