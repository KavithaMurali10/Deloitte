
public class Sum {

	public int addnumbers(int x,int y)
	{
		return x+y;
	}
}
