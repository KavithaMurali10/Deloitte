package program02;

  class Cat extends Animal{
	
	public void eat() {
		System.out.println("Cat eats milk");
		// TODO Auto-generated method stub
	

	}
	

}
