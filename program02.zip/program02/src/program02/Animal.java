package program02;

  abstract class Animal {
	
	public abstract void eat();
	
}