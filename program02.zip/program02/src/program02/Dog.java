package program02;

  class Dog extends Animal{
	
	public void eat() {
		System.out.println("Dog eats");
		
	}
	

}
